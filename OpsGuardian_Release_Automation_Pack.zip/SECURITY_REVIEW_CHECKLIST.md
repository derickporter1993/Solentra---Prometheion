# AppExchange Security Review — Prep Checklist (OpsGuardian)

## 1) Authentication & Secrets
- [ ] All external endpoints use **Named Credentials** or **External Credentials** (no secrets in code).
- [ ] Slack/Webhook URLs are **not** hardcoded; verified in Setup.
- [ ] Remote Site Settings avoided (prefer Named Credentials).

## 2) CRUD/FLS & Sharing
- [ ] All SOQL use `WITH SECURITY_ENFORCED` where possible.
- [ ] All DML guarded by `Security.stripInaccessible` for create/update/read.
- [ ] Apex classes use `with sharing` unless a justified exception exists.
- [ ] LWC/Invocable methods return only fields permitted by FLS.

## 3) Bulkification & Limits
- [ ] No SOQL/DML in loops; use collection patterns.
- [ ] Platform Event triggers bulk-tested (≥ 200 events).
- [ ] Async use respects limits; Slack batching implemented.

## 4) Callouts & Error Handling
- [ ] Timeouts set (≥10s). Backoff/retry for transient errors.
- [ ] Error paths tested (429/500); no unhandled exceptions surface to UI.

## 5) Logging & PII
- [ ] No PII in Debug logs. Use redaction where needed.
- [ ] Structured logs with correlation IDs for troubleshooting.

## 6) Packaging
- [ ] Unlocked Package builds; code-coverage ≥ 75% org-wide (aim ≥85%).
- [ ] Post-install script (if needed) minimal and idempotent.
- [ ] Security review questionnaire drafted with architecture diagrams.

## 7) Static Analysis Evidence
- [ ] PMD (sfdx-scanner) report with **zero high-severity** issues.
- [ ] Semgrep JS/LWC report captured.
- [ ] Dependency list (npm, sfdx) with versions and licenses.

## 8) Documentation
- [ ] Admin/setup guide (Named Credentials, permissions).
- [ ] Data handling policy; support contacts; issue reporting flow.
