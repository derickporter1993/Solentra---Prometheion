# OpsGuardian — Release Automation Pack

**Date:** November 03, 2025

This pack adds conventional-changelog powered releases, an Unlocked Package release script, and AppExchange Security Review prep.

## Steps
1. Patch `package.json` with `package.json.release.patch` and commit. Install dev deps.
2. Add `.github/workflows/release.yml` (already included).
3. Create or update `sfdx-project.json` using the included example.
4. Use `scripts/sf-package-release.sh` to create/promote package versions (requires org auth).
5. Keep `SECURITY_REVIEW_CHECKLIST.md` updated alongside PMD/Semgrep artifacts.

## CI Version Gate (optional)
Run `node scripts/versionGate.js` in CI to require at least one `feat:` or `fix:` commit before releasing.
