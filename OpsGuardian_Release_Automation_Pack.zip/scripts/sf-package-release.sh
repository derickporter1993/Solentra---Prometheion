#!/usr/bin/env bash
set -euo pipefail
# Usage: scripts/sf-package-release.sh PACKAGE_ALIAS="OpsGuardian" BRANCH="main"
PACKAGE_ALIAS="${PACKAGE_ALIAS:-OpsGuardian}"
BRANCH="${BRANCH:-main}"
ORG_ALIAS="${ORG_ALIAS:-CI}"

echo ">>> Using package alias: $PACKAGE_ALIAS"
echo ">>> Branch: $BRANCH"
echo ">>> Org alias: $ORG_ALIAS"

# Ensure org authenticated and project configured
sf --version
sf org display -o "$ORG_ALIAS" || { echo "Authenticate org first (sf org login ... -a $ORG_ALIAS)"; exit 1; }

# Create package if not exists
if ! sf package list --json | grep -q ""Name": "$PACKAGE_ALIAS""; then
  echo ">>> Creating package $PACKAGE_ALIAS"
  sf package create --name "$PACKAGE_ALIAS" --package-type Unlocked --path force-app
fi

# Create package version
echo ">>> Creating package version..."
sf package version create --package "$PACKAGE_ALIAS" -x --code-coverage --installation-key-bypass --wait 120 --json > pv.json
cat pv.json
VERSION_ID=$(cat pv.json | grep -oE "04t[0-9A-Za-z]{15,18}" || true)
if [ -z "$VERSION_ID" ]; then
  echo "Could not parse version ID (04t...). Check pv.json output."
  exit 2
fi
echo ">>> Candidate version: $VERSION_ID"

# Promote version
echo ">>> Promoting version $VERSION_ID"
sf package version promote -p "$VERSION_ID" -n

echo ">>> Done. Promoted package version: $VERSION_ID"
