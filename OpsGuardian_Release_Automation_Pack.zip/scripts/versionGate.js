// Enforce presence of at least one feat/fix between refs (default: origin/main..HEAD)
const { execSync } = require('child_process');
const fromRef = process.env.FROM_REF || 'origin/main';
const toRef = process.env.TO_REF || 'HEAD';

function log(cmd) { return execSync(cmd, { stdio: ['pipe', 'pipe', 'inherit'] }).toString().trim(); }

try {
  const msgs = log(`git log --pretty=%s ${fromRef}..${toRef}`)
    .split('\n')
    .filter(Boolean);
  const ok = msgs.some(m => /^feat\(|^feat:|^fix\(|^fix:/.test(m));
  console.log('Checked commits:');
  msgs.forEach(m => console.log('  -', m));
  if (!ok) {
    console.error('Version gate FAILED: no feat/fix commits found between', fromRef, 'and', toRef);
    process.exit(1);
  } else {
    console.log('Version gate PASSED: feat/fix present.');
  }
} catch (e) {
  console.error('Error running version gate:', e.message);
  process.exit(2);
}
