# Named Credential Setup — Slack Webhook

**Objective:** Securely route Slack notifications via a Named Credential so no webhook URL appears in Apex code.

## Steps (Salesforce Setup UI)
1. Go to **Setup → Security → Named Credentials**.
2. Click **New Named Credential**.
3. Fill:
   - **Label / Name:** `Slack_Webhook`
   - **URL:** paste your Slack incoming webhook URL (full URL including `/services/...`).
   - **Identity Type / Authentication:** `Anonymous`
   - **Allow Merge Fields in Header/Body:** `false` (default)
4. Save.

> If your org uses the newer **External Credentials** model, create an **External Credential (No Auth)** and then a **Named Credential** that references it. The included metadata file is the classic format; using Setup UI is simplest.

## Permissions
- Assign a Permission Set (e.g., `Prometheion_Notifications`) with **Apex Class Access** to `SlackNotifier` and **Named Credential access** to `Slack_Webhook` if your org enforces it.

## Test Callout
1. Open **Developer Console → Execute Anonymous**:
```
SlackNotifier.notifyAsync('Test message from Prometheion ✅');
```
2. Verify the message in your Slack channel.

## Troubleshooting
- **401/403**: Webhook invalid or revoked — replace URL.
- **429**: Rate-limited — the batch publisher truncates to 50 lines; consider multiple channels or App-level webhooks.
- **No message**: Check **Setup → Debug Logs** for `SlackNotifier` errors.
