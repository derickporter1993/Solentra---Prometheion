// force-app/main/default/lwc/apiUsageDashboard/apiUsageDashboard.js
import { LightningElement, track } from 'lwc';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import getSnapshots from '@salesforce/apex/ApiUsageDashboardController.recent';
import PollingManager from 'c/pollingManager';

export default class ApiUsageDashboard extends LightningElement {
  @track rows = [];
  polling;

  connectedCallback() {
    this.polling = new PollingManager(30000, () => this.refreshData());
    this.refreshData();
    this.polling.start();
  }

  disconnectedCallback() {
    if (this.polling) this.polling.stop();
  }

  async refreshData() {
    try {
      const data = await getSnapshots({ limitSize: 50 });
      this.rows = (data || []).map((r) => ({
        id: r.Id,
        name: r.Name,
        requests: r.Requests__c,
        timestamp: r.Timestamp__c,
        used: r.PercentUsed__c
      }));
    } catch (e) {
      this.dispatchEvent(new ShowToastEvent({
        title: 'Error loading API usage',
        message: e && e.body && e.body.message ? e.body.message : 'Unknown error',
        variant: 'error'
      }));
    }
  }
}
