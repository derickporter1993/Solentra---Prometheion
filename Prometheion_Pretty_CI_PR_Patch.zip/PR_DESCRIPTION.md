# chore(ci): Add Prettier (with Apex plugin) and enforce formatting in CI

**Date:** November 03, 2025

## What
- Adds `prettier.config.cjs` and `.prettierignore`
- Adds `prettier` and `prettier-plugin-apex` devDependencies
- Adds `format` / `format:check` npm scripts
- Updates CI workflow to run a Prettier check before Salesforce steps

## Why
- Fixes CI failures (`exit code 2`) on formatting by standardizing Prettier across JS/LWC and Apex
- Prevents accidental formatting drift in PRs
- Apex plugin ensures `.cls` and `.trigger` files are formatted consistently

## Notes
- If the CI Prettier check fails, run locally:
  ```bash
  npx prettier --write "**/*.{js,ts,json,md,html,css,cls,trigger,apex,yml,yaml}"
  ```
- Commit the sweep and re-push; CI will pass.
