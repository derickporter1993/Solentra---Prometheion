# Prometheion — Prettier + CI Patch

This pack prepares a PR to:
- Add Prettier v3 with Apex plugin (formats .cls/.trigger)
- Enforce Prettier in GitHub Actions
- Provide scripts for local formatting

## Quick Start
1. Unzip this pack into your repo *root*.
2. Run:
   ```bash
   bash apply_patch.sh
   npm run format || true
   git add -A && git commit -m "chore: add Prettier + CI check"
   git push -u origin feat/prettier-ci
   ```
3. Open a Pull Request using `PR_DESCRIPTION.md`.

## If patches don't apply cleanly
- Manually copy `prettier.config.cjs` and `.prettierignore`.
- Edit `package.json` to add `prettier` + `prettier-plugin-apex` and the `format` scripts.
- Insert the **Setup Node / Install Prettier / Prettier check** steps into your CI workflow.
