# Fixing the "Prettier check — Process completed with exit code 2" in GitHub Actions

## Root causes (most common)
1) Prettier not installed or wrong Node version.
2) Prettier is checking unsupported files (XML metadata, binaries).
3) Missing Apex parser plugin for .cls / .trigger files.
4) Syntax error in a checked file (exit code may be >1).

## Fast fix
1. Add `prettier.config.cjs` and `.prettierignore` from this pack.
2. Add dev deps: `npm i -D prettier prettier-plugin-apex`
3. Run locally:
   ```bash
   npx prettier --check "**/*.{js,ts,json,md,html,css,cls,trigger,apex,yml,yaml}"
   npx prettier --write "**/*.{js,ts,json,md,html,css,cls,trigger,apex,yml,yaml}"
   git add -A && git commit -m "style: apply Prettier formatting"
   ```
4. In GitHub Actions, insert the provided **Setup Node + Install + Check** steps before the rest of CI.

## Notes
- If you want CI to auto-fix formatting on PRs, create a separate workflow that runs on `pull_request_target` and pushes a commit (requires permissions).
- Keep `--check` in the main pipeline so formatting stays enforced.
- If you intentionally want to exclude XML or other assets, update `.prettierignore` or narrow the globs.
