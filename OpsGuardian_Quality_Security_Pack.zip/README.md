# OpsGuardian — Quality & Security Pack

**Date:** November 03, 2025

Adds Apex PMD rules, Semgrep scanning, and Conventional Commits enforcement.

## Integrate
1) Copy `config/` to repo root and add `.husky/` & `commitlint.config.cjs`.
2) Patch `package.json` with `package.json.commitlint.patch` and install dev deps.
3) Paste `github-actions/snippet-pmd-semgrep.yml` steps into your CI after checkout.
4) Run locally before pushing:
```
npx prettier --check "**/*.{js,ts,json,md,html,css,cls,trigger,apex,yml,yaml}"
python3 -m semgrep --config config/semgrep/semgrep.yml --error || true
sfdx scanner:run --engine pmd --target force-app --format table --pmdconfig config/pmd/apex-ruleset.xml || true
```
