#!/usr/bin/env sh
# minimal helper for Husky
