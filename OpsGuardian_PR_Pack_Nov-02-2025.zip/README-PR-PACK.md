# OpsGuardian PR Pack — Batch Slack, Security Enforcement, CI Gate
**Date:** November 03, 2025

This pack contains production-ready improvements:
- Batch Slack notifications via Queueable aggregator
- `WITH SECURITY_ENFORCED` + safer controller example
- LWC `pollingManager` default export + clean imports
- GitHub Actions workflow and coverage gate (85%)
- Named Credential template + setup guide

## Contents
- `.github/workflows/sf-ci.yml`
- `scripts/coverageGate.js`
- `force-app/main/default/namedCredentials/Slack_Webhook.namedCredential-meta.xml`
- `force-app/main/default/classes/SlackNotifier.cls` (+ meta)
- `force-app/main/default/classes/SlackFormatter.cls` (+ meta)
- `force-app/main/default/classes/SlackBatchPublisher.cls` (+ meta)
- `force-app/main/default/triggers/PerformanceAlertEventTrigger.trigger` (+ meta)
- `force-app/main/default/classes/ApiUsageDashboardController.cls` (+ meta)
- `force-app/main/default/lwc/pollingManager/pollingManager.js`
- `force-app/main/default/lwc/apiUsageDashboard/apiUsageDashboard.js`
- `docs/Named-Credential-Setup.md`

## How to Use
1. **Create a feature branch**: `git checkout -b feat/opsguardian-batched-alerts-ci`
2. **Copy files** from this pack into your repo matching paths above.
3. **Adjust names** if your existing classes use different names (e.g., your PE trigger). Only keep one trigger per object.
4. **Set Slack webhook** inside the Named Credential (via Setup UI or update metadata before deploy).
5. **Deploy** to a scratch org first:
   ```bash
   sf org create scratch -f config/project-scratch-def.json -a OG -y 1 -s
   sf project deploy start -o OG
   sf apex run test -o OG -r human
   ```
6. **Open PR**. GitHub Actions will enforce coverage ≥85% org-wide.

## Notes
- If your project already has a Slack notifier or PE trigger, merge logic rather than duplicate.
- The controller is an **example** showing `WITH SECURITY_ENFORCED`. Apply the pattern to your real controllers.
- The LWC change is safe: it standardizes to **default export/import** for the polling utility.
