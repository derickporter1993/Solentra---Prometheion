// force-app/main/default/lwc/pollingManager/pollingManager.js
export default class PollingManager {
  constructor(intervalMs, callback) {
    this.interval = intervalMs || 30000;
    this.callback = callback;
    this.handle = null;
    this.visibilityHandler = this.onVisibilityChange.bind(this);
  }
  start() {
    this.stop();
    this.handle = setInterval(() => {
      if (typeof this.callback === 'function') this.callback();
    }, this.interval);
    document.addEventListener('visibilitychange', this.visibilityHandler);
  }
  stop() {
    if (this.handle) {
      clearInterval(this.handle);
      this.handle = null;
    }
    document.removeEventListener('visibilitychange', this.visibilityHandler);
  }
  updateInterval(ms) {
    this.interval = ms;
    if (this.handle) {
      this.start();
    }
  }
  onVisibilityChange() {
    if (document.hidden) {
      if (this.handle) clearInterval(this.handle);
    } else {
      if (!this.handle) this.start();
    }
  }
}
