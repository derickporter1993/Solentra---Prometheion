// Simple coverage gate: reads Salesforce CLI JSON from stdin or file and enforces a minimum org-wide coverage percentage.
// Usage: node scripts/coverageGate.js 85 < results/apex-tests.json
const fs = require('fs');

function readStdinSync() {
  const BUFSIZE = 8192;
  let buf = Buffer.alloc(BUFSIZE);
  let bytesRead;
  let data = '';
  try {
    while ((bytesRead = fs.readSync(0, buf, 0, BUFSIZE, null)) > 0) {
      data += buf.toString('utf8', 0, bytesRead);
    }
  } catch (e) {
    // no stdin, ignore
  }
  return data;
}

const args = process.argv.slice(2);
const min = parseFloat(args[0] || '85');

let input = readStdinSync();
if (!input) {
  console.error('No JSON from stdin. Provide the sf apex run test JSON via stdin.');
  process.exit(2);
}

let json;
try {
  json = JSON.parse(input);
} catch (e) {
  console.error('Invalid JSON input:', e.message);
  process.exit(2);
}

// Try multiple shapes (sf vs sfdx formats)
let orgWide = null;
try {
  if (json.result && json.result.summary && typeof json.result.summary.orgWideCoverage !== 'undefined') {
    orgWide = parseFloat(json.result.summary.orgWideCoverage);
  } else if (json.summary && typeof json.summary.orgWideCoverage !== 'undefined') {
    orgWide = parseFloat(json.summary.orgWideCoverage);
  } else if (json.coverage && typeof json.coverage.coveragePercent !== 'undefined') {
    orgWide = parseFloat(json.coverage.coveragePercent);
  }
} catch (e) {}

if (orgWide === null || isNaN(orgWide)) {
  console.error('Could not determine org-wide coverage from test JSON. Looked for result.summary.orgWideCoverage or coverage.coveragePercent.');
  process.exit(2);
}

console.log(`Org-wide coverage: ${orgWide}% (minimum required: ${min}%)`);
if (orgWide < min) {
  console.error(`Coverage gate FAILED: ${orgWide}% < ${min}%`);
  process.exit(1);
} else {
  console.log('Coverage gate PASSED');
}
