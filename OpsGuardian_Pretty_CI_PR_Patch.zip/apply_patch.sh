#!/usr/bin/env bash
set -euo pipefail

# Apply PR-ready patch to add Prettier + Apex plugin and update CI.
# Usage: from your repo root (after unzipping this pack there):
#   bash apply_patch.sh
# Review changes, run locally:
#   npm i
#   npm run format:check || npm run format && git add -A && git commit -m "style: Prettier sweep"
#   git push -u origin feat/prettier-ci

BRANCH="${1:-feat/prettier-ci}"

echo ">>> Creating branch: $BRANCH"
git checkout -b "$BRANCH" || git checkout "$BRANCH"

echo ">>> Adding Prettier config files"
cp -f ./prettier.config.cjs . || true
cp -f ./.prettierignore . || true

echo ">>> Patching package.json"
git apply --reject --whitespace=fix package.json.patch || true

echo ">>> Patching workflow"
mkdir -p .github/workflows
git apply --reject --whitespace=fix .github/workflows/sf-ci.yml.patch || true

echo ">>> Installing dev dependencies"
if [ -f package.json ]; then
  npm i -D prettier@^3 prettier-plugin-apex@^2 || true
fi

echo ">>> Running Prettier check (may fail if formatting needed)"
npx prettier --check "**/*.{js,ts,json,md,html,css,cls,trigger,apex,yml,yaml}" || true

echo ">>> If the previous step reported files to format, run:"
echo "    npx prettier --write \"**/*.{js,ts,json,md,html,css,cls,trigger,apex,yml,yaml}\""
echo "    git add -A && git commit -m \"style: Prettier sweep\""
echo ">>> Then push your branch and open a PR."
