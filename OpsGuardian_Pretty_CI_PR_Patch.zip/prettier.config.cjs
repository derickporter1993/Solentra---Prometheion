// Prettier config for OpsGuardian (Prettier v3.x)
/** @type {import('prettier').Config} */
module.exports = {
  printWidth: 100,
  singleQuote: true,
  trailingComma: "all",
  arrowParens: "always",
  overrides: [
    { files: "*.cls", options: { parser: "apex" } },
    { files: "*.trigger", options: { parser: "apex" } },
    { files: "*.apex", options: { parser: "apex" } },
    { files: "*.md", options: { proseWrap: "always" } }
  ],
  plugins: ["prettier-plugin-apex"]
};
